function changeColorAndBorder() {
    	var borderR = document.getElementById("borderR").value;
    	var borderG = document.getElementById("borderG").value;
    	var borderB = document.getElementById("borderB").value;
    	var border_w = document.getElementById("border_w").value;
    	var bgR = document.getElementById("bgR").value;
    	var bgG = document.getElementById("bgG").value;
    	var bgB = document.getElementById("bgB").value;

	var paragraph = document.getElementById("paragraph");
    	paragraph.style.borderColor = `rgb(${borderR},${borderG},${borderB})`;
    	paragraph.style.borderWidth = border_w
    	paragraph.style.backgroundColor = `rgb(${bgR},${bgG},${bgB})`;
}

function password() {
	var first_p = document.getElementById("first_p").value;
	var second_p = document.getElementById("second_p").value;

	if (first_p == second_p) {
		alert("The passwords match!")
	} else if (first_p.length < 8) {
		alert("The length of the first passowrd is less than 8 letters!")
	} else if (second_p.length < 8) {
		alert("The length of the second password is less than 8 letters!")
	} else {
		alert("The passwords do not match!")
	}
}
